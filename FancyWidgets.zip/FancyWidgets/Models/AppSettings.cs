﻿namespace FancyWidgets.Models;

public class AppSettings
{
    public const string WidgetMetadataFile = "metadata.json";
    public const string WidgetSettingsFile = "widgetSettings.json";
}